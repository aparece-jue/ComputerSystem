import { Plugin } from "obsidian";
import { StreamLanguage } from "@codemirror/stream-parser";
import { Extension } from "@codemirror/state";

// 推荐方式导入高亮样式与标签
import { HighlightStyle, tags } from "@codemirror/highlight";

// 自定义 stream-parser 语言定义
import { defineAsmLanguage } from "./stream-asm";

export default class ASMSyntaxHighlightPlugin extends Plugin {
  async onload() {
    console.log("[ASM Plugin] ✅ Plugin loading (string-based highlighting)...");

    const asmLang = StreamLanguage.define(defineAsmLanguage());

    const asmHighlightStyle = HighlightStyle.define([
      { tag: tags.keyword, color: "#d73a49" },
      { tag: tags.comment, color: "#6a737d", fontStyle: "italic" },
      { tag: tags.number, color: "#005cc5" },
      { tag: tags.variableName, color: "#e36209" }
    ]);

    const asmExtension: Extension = [
      asmLang,
      asmHighlightStyle
    ];

    this.registerEditorExtension(asmExtension);
    console.log("[ASM Plugin] ✅ Editor highlighter registered");

    // Prism 阅读视图渲染
    this.registerMarkdownCodeBlockProcessor("x86asm", async (source, el) => {
      const pre = document.createElement("pre");
      const code = document.createElement("code");
      code.className = "language-x86asm";
      code.textContent = source;
      pre.appendChild(code);
      el.appendChild(pre);
      await (window as any).Prism?.highlightElement(code);
    });

    console.log("[ASM Plugin] ✅ Prism reader registered");
  }

  onunload() {
    console.log("[ASM Plugin] 🛑 Plugin unloaded");
  }
}
